package gp_system;

import java.awt.event.ActionListener;

/**
 *  GamePauseModel
 *  This class is in charger of the Model
 *  Middle-man between View and Controller
 */

public class GamePauseModel {

}
