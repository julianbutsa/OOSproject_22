package gp_system;

import java.awt.Color;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

//import com.sun.prism.paint.Color;

public class SidePanel extends JPanel{

	private JTextField searchbar;
	private JPanel viewer;
	private JLabel panelLabel;
	
	public SidePanel(){
		this.viewer = new JPanel();
		this.searchbar = new JTextField();
		this.panelLabel = new JLabel("This is the sidebar");
		this.setBackground(Color.black);
		this.add(this.panelLabel);
		this.add(this.searchbar);
		
	}
	
}
