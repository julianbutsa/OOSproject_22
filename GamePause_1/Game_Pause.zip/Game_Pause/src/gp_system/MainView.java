package gp_system;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class MainView extends JFrame{
	private GamePauseView currentView;
	private JPanel sidepanel;
	private JPanel bannerpanel;
	private JPanel middlepanel;
	
	private JFrame mainView;

	
	public MainView(){
		this.mainView = new JFrame();
		this.setLayout(new GridBagLayout());
		GridBagConstraints c = new GridBagConstraints();
		this.sidepanel = new SidePanel();
		c.gridy = 2;
		c.gridheight = 2;//GridBagConstraints.REMAINDER;
		this.add(this.sidepanel,c );
		this.bannerpanel = new BannerPanel();
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 100;
		c.gridwidth = 10;
		c.fill = GridBagConstraints.HORIZONTAL;
		this.add(this.bannerpanel,c );
		this.middlepanel = new MiddlePanel();
		c.gridx = 2;
		c.gridy = 2;
		c.gridwidth = GridBagConstraints.REMAINDER;
		c.gridheight = GridBagConstraints.REMAINDER;
		this.add(this.middlepanel,c );
		/*
		this.add(]);
		this.add());
		*/
	}

	public void register(GamePauseControllerV2 controller) {
		// TODO Auto-generated method stub
		
	}

}
