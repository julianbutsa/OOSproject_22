package gp_system;

import java.awt.Color;

import javax.swing.JLabel;
import javax.swing.JPanel;

public class BannerPanel extends JPanel{
	private JLabel panelLabel;

	public BannerPanel(){
		this.panelLabel = new JLabel("This is the banner");
		this.add(this.panelLabel);
		this.setBackground(Color.RED);
	}
}
