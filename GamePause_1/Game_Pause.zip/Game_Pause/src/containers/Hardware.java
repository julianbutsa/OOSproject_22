package containers;

public class Hardware extends Item {

	private String itemtype;
	
	public String getItemtype() {
		return itemtype;
	}
	public void setItemtype(String itemtype) {
		this.itemtype = itemtype;
	}
	
}
