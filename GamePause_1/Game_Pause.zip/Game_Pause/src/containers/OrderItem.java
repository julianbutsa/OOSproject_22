package containers;

public class OrderItem {
	private Item i;
	private int quantity;
	
	
	
	public Item getI() {
		return i;
	}
	public void setI(Item i) {
		this.i = i;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	

}
